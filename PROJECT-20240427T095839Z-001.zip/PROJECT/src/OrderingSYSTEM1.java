
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.stage.FileChooser;
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import static javafx.application.Application.launch;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.layout.Background;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Screen;

public class OrderingSYSTEM1 extends Application {

    private static ObservableList<OrderItem> orders = FXCollections.observableArrayList();
    private static final String HEADER_TEXT = "Welcome to SuppPressOr";
    private ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

    public static void main(String[] args) {
        launch(args);
    }

    private void switchTabAnimation(Tab oldTab, Tab newTab) {
        if (oldTab == null || newTab == null) {
            return;
        }

        Node oldContent = oldTab.getContent();
        Node newContent = newTab.getContent();

        FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.2), oldContent);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(event -> {
            oldContent.setVisible(false);
            newContent.setVisible(true);
            newContent.setOpacity(0.0);

            FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.2), newContent);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        });
        fadeOut.play();
    }

    private String generateOrderCode() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder codeBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
            char randomChar = characters.charAt(random.nextInt(characters.length()));
            codeBuilder.append(randomChar);
        }
        return codeBuilder.toString();
    }

    private void createDialog(String title, String headerText, String contentText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);

        alert.getDialogPane().setStyle("-fx-font-size: 20px;");

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.5), alert.getDialogPane());
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.play();

        alert.showAndWait();
    }

    int index = 0;

    public void typewriter(String word, Text txt) {

        executor.scheduleAtFixedRate(() -> {

            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.seconds(0.1), event -> {
                        if (index <= word.length()) {
                            txt.setText(word.substring(0, index++));
                        }
                    })
            );
            timeline.setCycleCount(word.length() + 1);
            timeline.play();

            index = 0;

        }, 0, 10, TimeUnit.SECONDS);

    }
// Method to append spaces to the StringBuilder

    private void appendSpaces(StringBuilder builder, int count) {
        for (int i = 0; i < count; i++) {
            builder.append(" ");
        }
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Ordering System");

        Text headerText = new Text();
        headerText.setFont(Font.font("Arial", FontWeight.BOLD, 48));
        // Define the colors for the gradient
        Stop[] stops = new Stop[]{
            new Stop(0, Color.GREEN),
            new Stop(1, Color.ORANGE)
        };

        LinearGradient gradient = new LinearGradient(
                0, 0, 1, 0, true, CycleMethod.NO_CYCLE, stops);

        headerText.setFill(gradient);

        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(1), headerText);
        translateTransition.setFromY(-100);
        translateTransition.setToY(0);
        translateTransition.play();
        typewriter(HEADER_TEXT, headerText);

        BorderPane headerPane = new BorderPane();
        headerPane.setPadding(new Insets(20));
        headerPane.setCenter(headerText);

        Button backButton = new Button("Back");
        backButton.setId("backButton");
        backButton.setOnAction(e -> {
            Home home = new Home();
            try {
                home.start(primaryStage);
            } catch (Exception ex) {
                Logger.getLogger(OrderingSYSTEM.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
        headerPane.setLeft(backButton);
        ImageView logoImageView = new ImageView(new Image(getClass().getResourceAsStream("Images/logs.png")));
        logoImageView.setFitWidth(100);
        logoImageView.setFitHeight(80);

        StackPane logoPane = new StackPane(logoImageView);
        logoPane.setAlignment(Pos.TOP_RIGHT);
        logoPane.setPadding(new Insets(10));

        headerPane.setRight(logoPane);

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab tab1 = new Tab("PAPERS");
        Tab tab2 = new Tab("PENS");
        Tab tab3 = new Tab("OTHERS");
        tabPane.setStyle("-fx-cursor: hand;");
        tabPane.getStyleClass().add("custom-tab-pane");

        tabPane.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
            if (newTab != null) {
                switchTabAnimation(oldTab, newTab);
            }
        });
        ObservableList<MenuItem> menuItems1 = FXCollections.observableArrayList(
                new MenuItem("1 Whole Sheet of Paper", 25, "Images/1whole.png", 100),
                new MenuItem("1/2 Lenghtwise", 15, "Images/lengthwise.png", 100),
                new MenuItem("1/2 Crosswise", 15, "Images/cross (2).png", 100),
                new MenuItem("1/4 Sheet of Paper", 10, "Images/14.png", 100),
                new MenuItem("YellowPad", 45, "Images/yellowpad.png", 100),
                new MenuItem("LongBond Paper", 1, "Images/a444.png", 100),
                new MenuItem("ShortBond Paper", 1, "Images/a444.png", 100),
                new MenuItem("A4 Paper", 1, "Images/a444.png", 100),
                new MenuItem("Oslo Paper", 2, "Images/oslo.png", 100),
                new MenuItem("1/2 Index Card", 2, "Images/index.png", 100),
                new MenuItem("White Short Folder", 7, "Images/white.png", 100),
                new MenuItem("Black Short Folder", 10, "Images/black (1).png", 100),
                new MenuItem("Orange Short Folder", 10, "Images/orange.png", 100),
                new MenuItem("Brown Short Folder", 10, "Images/brown.png", 100),
                new MenuItem("Red Short Folder", 10, "Images/red.png", 100),
                new MenuItem("White Long Folder", 10, "Images/white.png", 100),
                new MenuItem("Black Long Folder", 13, "Images/black (1).png", 100),
                new MenuItem("Orange Long Folder", 13, "Images/orange.png", 100),
                new MenuItem("Brown Long Folder", 13, "Images/brown.png", 100),
                new MenuItem("Red Long Folder", 13, "Images/red.png", 100)
        );
        ObservableList<MenuItem> menuItems2 = FXCollections.observableArrayList(
                new MenuItem("Black Ballpen", 10, "Images/ballpen black.png", 100),
                new MenuItem("Red Ballpen", 10, "Images/red ballpen.png", 100),
                new MenuItem("Blue Ballpen", 10, "Images/blue ballpen.png", 100),
                new MenuItem("Highlighter", 15, "Images/highlighter.png", 100),
                new MenuItem("Pencil", 10, "Images/pencil.png", 100),
                new MenuItem("Black Marker", 15, "Images/pentelpen blck.png", 100),
                new MenuItem("Red Marker", 15, "Images/pentelpen red.png", 100),
                new MenuItem("Blue Marker", 15, "Images/pentelpen blue.png", 100),
                new MenuItem("Crayon", 35, "Images/crayons.png", 100),
                new MenuItem("Coloring Book", 35, "Images/color pencil.png", 100)
        );
        ObservableList<MenuItem> menuItems3 = FXCollections.observableArrayList(
                new MenuItem("Fastener", 3, "Images/fastener.png", 100),
                new MenuItem("Clips", 5, "Images/clips.png", 100),
                new MenuItem("Sharpener", 5, "Images/sharpener (1).png", 100),
                new MenuItem("Glue Stick", 5, "Images/GLUESTICK1.png", 100),
                new MenuItem("Eraser", 10, "Images/eraser.png", 100),
                new MenuItem("Plastic Cover", 20, "Images/cover.png", 100),
                new MenuItem("Scissor", 15, "Images/sciss.png", 100),
                new MenuItem("Glue", 15, "Images/glue.png", 100),
                new MenuItem("Ruler", 10, "Images/rul.png", 100),
                new MenuItem("Correction Tape", 25, "Images/tape.png", 100)
        );

        ListView<MenuItem> menuListView1 = new ListView<>(menuItems1);
        ListView<MenuItem> menuListView2 = new ListView<>(menuItems2);
        ListView<MenuItem> menuListView3 = new ListView<>(menuItems3);

        menuListView1.setCellFactory(param -> new MenuItemCell());
        menuListView1.setPrefSize(1000, 700);
        menuListView1.setStyle("-fx-padding: 5px;");

        menuListView2.setCellFactory(param -> new MenuItemCell());
        menuListView2.setPrefSize(1000, 700);
        menuListView2.setStyle("-fx-padding: 5px;");

        menuListView3.setCellFactory(param -> new MenuItemCell());
        menuListView3.setPrefSize(1000, 700);
        menuListView3.setStyle("-fx-padding: 5px;");

        tab1.setContent(menuListView1);
        tab2.setContent(menuListView2);
        tab3.setContent(menuListView3);

        tabPane.getTabs().addAll(tab1, tab2, tab3);

        ListView<OrderItem> orderListView = new ListView<>(orders);
        orderListView.setCellFactory(param -> new OrderItemCell());
        orderListView.setPrefSize(1000, 700);
        orderListView.setStyle("-fx-padding: 5px;");

        Button orderButton = new Button("Add to Order");
        Button removeButton = new Button("Remove from Order");
        Button clearButton = new Button("Clear Order");
        Button totalButton = new Button("Total");
        orderButton.disableProperty().bind(menuListView1.getSelectionModel().selectedItemProperty().isNull()
                .and(menuListView2.getSelectionModel().selectedItemProperty().isNull())
                .and(menuListView3.getSelectionModel().selectedItemProperty().isNull()));

        orderButton.getStyleClass().add("button");
        removeButton.getStyleClass().add("button");
        clearButton.getStyleClass().add("button");
        totalButton.getStyleClass().add("button");
        orderButton.setOnAction(e -> {
            Tab selectedTab = tabPane.getSelectionModel().getSelectedItem();
            if (selectedTab == tab1) {
                MenuItem selectedItem = menuListView1.getSelectionModel().getSelectedItem();
                if (selectedItem != null) {
                    TextInputDialog dialog = new TextInputDialog("1");
                    dialog.setTitle("Quantity Input");
                    dialog.setHeaderText("How many you'd like to order for " + selectedItem.getName());
                    dialog.setContentText("Quantity:");
                    dialog.getEditor().setTextFormatter(new TextFormatter<>(change -> {
                        if (change.getControlNewText().length() <= 3 && change.getControlNewText().matches("\\d*")) {
                            return change;
                        }
                        return null;
                    }));

                    Optional<String> result = dialog.showAndWait();
                    result.ifPresent(quantityStr -> {
                        try {
                            int quantity = Integer.parseInt(quantityStr);
                            if (quantity > 0 && quantity <= selectedItem.getStock()) {
                                orders.add(new OrderItem(selectedItem, quantity));
                            } else {
                                createDialog("Insufficient Stock", null, "There is not enough stock for this item.");
                            }
                        } catch (NumberFormatException ex) {
                        }
                    });
                }
            } else if (selectedTab == tab2) {
                MenuItem selectedItem = menuListView2.getSelectionModel().getSelectedItem();
                if (selectedItem != null) {
                    TextInputDialog dialog = new TextInputDialog("1");
                    dialog.setTitle("Quantity Input");
                    dialog.setHeaderText("How many you'd like to order for " + selectedItem.getName());
                    dialog.setContentText("Quantity:");
                    dialog.getEditor().setTextFormatter(new TextFormatter<>(change -> {
                        if (change.getControlNewText().length() <= 3 && change.getControlNewText().matches("\\d*")) {
                            return change;
                        }
                        return null;
                    }));

                    Optional<String> result = dialog.showAndWait();
                    result.ifPresent(quantityStr -> {
                        try {
                            int quantity = Integer.parseInt(quantityStr);
                            if (quantity > 0 && quantity <= selectedItem.getStock()) {
                                orders.add(new OrderItem(selectedItem, quantity));
                            } else {
                                createDialog("Insufficient Stock", null, "There is not enough stock for this item.");
                            }
                        } catch (NumberFormatException ex) {
                        }
                    });
                }
            } else if (selectedTab == tab3) {
                MenuItem selectedItem = menuListView3.getSelectionModel().getSelectedItem();
                if (selectedItem != null) {
                    TextInputDialog dialog = new TextInputDialog("1");
                    dialog.setTitle("Quantity Input");
                    dialog.setHeaderText("How many you'd like to order for " + selectedItem.getName());
                    dialog.setContentText("Quantity:");
                    dialog.getEditor().setTextFormatter(new TextFormatter<>(change -> {
                        if (change.getControlNewText().length() <= 3 && change.getControlNewText().matches("\\d*")) {
                            return change;
                        }
                        return null;
                    }));

                    Optional<String> result = dialog.showAndWait();
                    result.ifPresent(quantityStr -> {
                        try {
                            int quantity = Integer.parseInt(quantityStr);
                            if (quantity > 0 && quantity <= selectedItem.getStock()) {
                                orders.add(new OrderItem(selectedItem, quantity));
                            } else {
                                createDialog("Insufficient Stock", null, "There is not enough stock for this item.");
                            }
                        } catch (NumberFormatException ex) {
                        }
                    });
                }
            }

        });

        removeButton.setOnAction(e -> {
            OrderItem selectedItem = orderListView.getSelectionModel().getSelectedItem();
            if (selectedItem != null) {
                if (selectedItem.getQuantity() > 1) {
                    selectedItem.setQuantity(selectedItem.getQuantity() - 1);
                } else {
                    orders.remove(selectedItem);
                }
            } else {
                createDialog("No Item Selected", null, "Please select an item to remove.");
            }
        });

        clearButton.setOnAction(e -> orders.clear());

        totalButton.setOnAction(e -> {
            StringBuilder receiptBuilder = new StringBuilder();
            receiptBuilder.append("================================\n");
            receiptBuilder.append("            RECEIPT           \n");
            receiptBuilder.append("================================\n");
            receiptBuilder.append("Date: ").append(java.time.LocalDate.now()).append("\n");
            receiptBuilder.append("Item                                   Qty  Price        Total\n");
            receiptBuilder.append("---------------------------------------------\n");
            double totalPrice = 0;
            int totalQuantity = 0;

            // Find the maximum lengths for each column
            int maxItemLength = orders.stream()
                    .mapToInt(item -> item.getMenuItem().getName().length())
                    .max().orElse(0);

            for (OrderItem item : orders) {
                double itemTotalPrice = item.getMenuItem().getPrice() * item.getQuantity();
                receiptBuilder.append(item.getMenuItem().getName());
                appendSpaces(receiptBuilder, maxItemLength - item.getMenuItem().getName().length() + 5);
                receiptBuilder.append(item.getQuantity());
                appendSpaces(receiptBuilder, 5);
                receiptBuilder.append("₱").append(item.getMenuItem().getPrice());
                appendSpaces(receiptBuilder, 8);
                receiptBuilder.append("₱").append(itemTotalPrice).append("\n");
                totalPrice += itemTotalPrice;
                totalQuantity += item.getQuantity();
            }
            receiptBuilder.append("---------------------------------------------\n");
            receiptBuilder.append("Total Quantity:");
            appendSpaces(receiptBuilder, 19);
            receiptBuilder.append(totalQuantity).append("\n");
            receiptBuilder.append("Total Price:");
            appendSpaces(receiptBuilder, 49);
            receiptBuilder.append("₱").append(totalPrice).append("\n\n");
            receiptBuilder.append("Order Code: ").append(generateOrderCode()).append("\n");
            receiptBuilder.append("Thank you for your order!");

            TextArea textArea = new TextArea(receiptBuilder.toString());
            textArea.setEditable(false);
            textArea.setPrefSize(400, 300);

            Button saveButton = new Button("Print");
            saveButton.setOnAction(event -> {
                FileChooser fileChooser = new FileChooser();
                fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
                File file = fileChooser.showSaveDialog(primaryStage);

                if (file != null) {
                    try (PrintWriter writer = new PrintWriter(file)) {
                        writer.println(receiptBuilder.toString());
                        System.out.println("Receipt saved to: " + file.getAbsolutePath());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Receipt Saved");
                        alert.setHeaderText(null);
                        alert.setContentText("Receipt saved to: " + file.getAbsolutePath());
                        alert.showAndWait();
                    } catch (FileNotFoundException ex) {
                        System.out.println("Failed to save receipt: " + ex.getMessage());
                    }
                }
            });

            VBox vbox = new VBox(10, textArea, saveButton);
            vbox.setAlignment(Pos.CENTER);

            Dialog<Void> dialog = new Dialog<>();
            dialog.setTitle("Receipt");
            dialog.getDialogPane().setContent(vbox);

            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
            dialog.showAndWait();
        });

        HBox buttonBox = new HBox(10, orderButton, removeButton, clearButton, totalButton);
        buttonBox.setPadding(new Insets(10));
        buttonBox.getStyleClass().add("button-box");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Label menuLabel = new Label("ITEMS");
        menuLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        Label orderLabel = new Label("ORDER");
        orderLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        gridPane.add(menuLabel, 0, 0);
        gridPane.add(tabPane, 0, 1);

        gridPane.add(orderLabel, 1, 0);
        gridPane.add(orderListView, 1, 1);

        VBox centerBox = new VBox(20, gridPane, buttonBox);
        centerBox.setPadding(new Insets(10));
        centerBox.setAlignment(Pos.CENTER);

        BorderPane borderPane = new BorderPane();
        borderPane.setTop(headerPane);
        borderPane.setCenter(centerBox);

        borderPane.setOnMouseClicked(e -> {
            menuListView1.getSelectionModel().clearSelection();
            menuListView2.getSelectionModel().clearSelection();
            menuListView3.getSelectionModel().clearSelection();
            orderListView.getSelectionModel().clearSelection();
        });
        orderListView.setOnMouseClicked(e -> {
            menuListView1.getSelectionModel().clearSelection();
            menuListView2.getSelectionModel().clearSelection();
            menuListView3.getSelectionModel().clearSelection();
        });
        menuListView1.setOnMouseClicked(e -> {
            orderListView.getSelectionModel().clearSelection();
        });
        menuListView2.setOnMouseClicked(e -> {
            orderListView.getSelectionModel().clearSelection();
        });
        menuListView3.setOnMouseClicked(e -> {
            orderListView.getSelectionModel().clearSelection();
        });

        StackPane root = new StackPane(borderPane);
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #add8e6, #90ee90);");

        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());

        primaryStage.setTitle("Ordering System");
        primaryStage.setScene(scene);
        primaryStage.setWidth(1920);
        primaryStage.setHeight(1028);
        primaryStage.show();

        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        primaryStage.setX((screenBounds.getWidth() - primaryStage.getWidth()) / 2);
        primaryStage.setY((screenBounds.getHeight() - primaryStage.getHeight()) / 2);
    }

    public static class MenuItem {

        private String name;
        private double price;
        private String imagePath;
        private int stock;

        public MenuItem(String name, double price, String imagePath, int stock) {
            this.name = name;
            this.price = price;
            this.imagePath = imagePath;
            this.stock = stock;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public String getImagePath() {
            return imagePath;
        }

        public int getStock() {
            return stock;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }

        @Override
        public String toString() {
            return name + " - ₱" + price;
        }

        public void restock(int quantity) {
            stock += quantity;
        }
    }

    public static class OrderItem {

        private MenuItem menuItem;
        private int quantity;

        public OrderItem(MenuItem menuItem, int quantity) {
            this.menuItem = menuItem;
            this.quantity = quantity;
            // Reduce stock when an item is ordered
            this.menuItem.setStock(this.menuItem.getStock() - quantity);
        }

        public MenuItem getMenuItem() {
            return menuItem;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            // Update stock when quantity changes
            int diff = quantity - this.quantity;
            this.menuItem.setStock(this.menuItem.getStock() - diff);
            this.quantity = quantity;
        }

        public double getTotalPrice() {
            return menuItem.getPrice() * quantity;
        }
    }

    public static class MenuItemCell extends ListCell<MenuItem> {

        private void createDialog(String title, String headerText, String contentText) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(title);
            alert.setHeaderText(headerText);
            alert.setContentText(contentText);

            // Set font size for title, header text, and content text
            alert.getDialogPane().setStyle("-fx-font-size: 20px;");

            // Add fade-in animation
            FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.1), alert.getDialogPane());
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();

            alert.showAndWait();
        }

        @Override
        protected void updateItem(MenuItem item, boolean empty) {

            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                setText(item.getName() + " - ₱" + item.getPrice());
                ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream(item.getImagePath())));
                imageView.setFitWidth(200);
                imageView.setFitHeight(200);
                imageView.setStyle("-fx-border-color: blue; -fx-border-width: 2px;");
                setGraphic(imageView);
                setFont(Font.font("Arial", FontWeight.BOLD, 24));
            }
        }
    }

    public static class OrderItemCell extends ListCell<OrderItem> {

        @Override
        protected void updateItem(OrderItem item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                setText(item.getMenuItem().getName() + " - ₱" + item.getMenuItem().getPrice() + " x" + item.getQuantity());
                ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream(item.getMenuItem().getImagePath())));
                imageView.setFitWidth(200);
                imageView.setFitHeight(200);
                imageView.setStyle("-fx-border-color: blue; -fx-border-width: 2px;");
                setGraphic(imageView);
                setFont(Font.font("Arial", FontWeight.BOLD, 24));
            }
        }
    }

}
