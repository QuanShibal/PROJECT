import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

public class Admin extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("admin.fxml"));

        TextField adminText = (TextField) root.lookup("#user");
        TextField adminsText = (TextField) root.lookup("#admins");
        PasswordField passText = (PasswordField) root.lookup("#pass");
        CheckBox check = (CheckBox) root.lookup("#check");
        Button login = (Button) root.lookup("#login");

        // Set maximum length for the password field
        int maxTextLength = 25; // Adjust as needed
        setMaxLength(passText, maxTextLength);

        check.setOnAction(event -> {
            if (check.isSelected()) {
                adminsText.setText(passText.getText()); // Make sure text is visible
                adminsText.toFront();
            } else {
                passText.setText(adminsText.getText()); // Make sure text is visible
                passText.toFront();
            }
        });

        login.setOnAction(event -> {
            String username = adminText.getText();
            String password = passText.getText();

            if (username.equals("admin") && password.equals("password")) {
                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome, Admin!");
                OrderingSYSTEM order = new OrderingSYSTEM();
                order.start(primaryStage);
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid username or password.");
            }
        });

        Scene scene = new Scene(root, 1920, 1028.0);
        scene.getStylesheets().add(getClass().getResource("admin.css").toExternalForm());

        primaryStage.setTitle("ADMIN LOGIN");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setFullScreenExitHint("");
        primaryStage.setFullScreen(false);
        primaryStage.show();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        alert.showAndWait();
    }

    private void setMaxLength(TextField textField, int maxLength) {
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.length() > maxLength) {
                textField.setText(oldValue);
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
