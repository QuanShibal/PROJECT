import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class Home extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
        Button admin = (Button) root.lookup("#admin");
        Button user = (Button) root.lookup("#user");
        
        Admin admins = new Admin();
        OrderingSYSTEM1 order = new OrderingSYSTEM1();

        admin.setOnAction(event -> {
            try {
                admins.start(primaryStage);
            } catch (Exception ex) {
                Logger.getLogger(Home.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        user.setOnAction(event -> {
            order.start(primaryStage);
        });


        Scene scene = new Scene(root, 1920, 1028.0);
        scene.getStylesheets().add(getClass().getResource("home.css").toExternalForm());

        primaryStage.setTitle("HOME");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setFullScreenExitHint("");
        primaryStage.setFullScreen(false);

        primaryStage.show();

        // Center the stage on the screen
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        primaryStage.setX((screenBounds.getWidth() - primaryStage.getWidth()) / 2);
        primaryStage.setY((screenBounds.getHeight() - primaryStage.getHeight()) / 2);
    }

    public static void main(String[] args) {
        launch(args);
    }

}
